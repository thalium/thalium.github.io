# The Calculator in Shadow

## Introduction

_ALICE has a secret: it is not really good at mental calculations._

_However, fret not, since ALICE solved the issue by emulating a RISCV 64-bit processor, and running a custom calculator on top of it. (Yes, you heard it right, and yes, it seems overly complicated for a calculator, but can we really understand ALICE's reasons?)_

_We think that we may gain some way to fight ALICE by exploiting its calculator, so we secured an access to it! We also got a leak of the source, you will therefore find it attached. Hey, aren't we efficient? Now's your turn to act! However it seems ALICE doesn't emulate a standard RISCV 64-bit processor, but added an obscure thing to it. There are, consequently, custom instuctions in the calculator code. Well, now that seems very shady..._

**You will be able to run a calculation on ALICE's calculator in production. Your goal will be to read a file containing the flag (for example by getting a shell from the calculator).**

## Download the docker image

During the ECW 2023, a convenient docker image was available to download.
You can rebuild it using the provided Dockerfile (it is quite long).

It contains:
- a Linux environment.
- the calculator (build & source).
- a custom QEMU to emulate ALICE's RISCV processor (build & source).
- a RISCV Linux sysroot (with a lightly customized binutils).
- a preconfigured pwndbg debugger.

## Use the docker image

Import the downloaded image:
```bash
docker load -i obscurity.tar
```

Create a container from the image:
```bash
docker run -it obscurity
```

Get a new shell in your container (if needed):
```bash
docker exec -it YOUR_CONTAINER_ID /bin/bash
```
Note: it is recommanded to use a `bash` shell inside the container to make use of the added config in `.bashrc`.

### Once in the container

Launch the calculator with the alias: `calculator`.

Launch the calculator for debug with the alias: `calculator-gdb`. It will wait for a debugger on port `1337` before to start execution.

Launch the preconfigured pwndbg debugger with: `gdb-multiarch`.

## What's included in this zip?

The `src/` folder contains:
- the source of the calculator.
- the patch applied to get the custom QEMU that emulates ALICE's RISCV processor.
- the patch applied to binutils for getting the corresponding custom instructions.

You may use the `build/` folder in this archive as an alternative to the docker image. **However, note that you should expect ALICE's calculator in production to behave like the provided docker image, so using the `build/` folder instead is NOT RECOMMENDED.**

The `build/` folder contains:
- binaries for the calculator.
- a custom QEMU to emulate ALICE's RISCV processor.
- the corresponding RISCV Linux sysroot.

Lastly an optional `Dockerfile` and `.gdbinit` are provided if you want to rebuild the docker image (however this is quite long so it is again NOT RECOMMENDED).

## Some extra details

The patch `qemu.diff` was applied on the QEMU Linux 64-RISCV User space emulator release [v8.0.3](https://github.com/qemu/qemu/releases/tag/v8.0.3).

The calculator was built with the RISCV toolchain release [2023.07.07](https://github.com/riscv-collab/riscv-gnu-toolchain/releases/tag/2023.07.07).

The patch `binutils.diff` was applied in the `binutil` folder of this toolchain.

You can rebuild the calculator with just the `make` command.

You can also rebuild the calculator without custom instrutions with `make sunbath`. You will still need the RISCV Toolchain, but the normal version (without the patch) will suffice.

## Docker alternative (NOT RECOMMENDED)

Inside the `build` folder, run ALICE's calculator (on Linux) with:
```bash
./qemu-riscv64-shadow -L ./sysroot ./calculator-shadow
```

If you have trouble debugging, we advise to use gdb-multiarch with pwndbg as it seems to behave better that other gdb extensions for a remote 64-bit RISCV context.

If you have a standard `qemu-riscv64` on your system, you can also run a version of ALICE's calculator free of the shady custom instructions with:
```bash
qemu-riscv64 -L ./sysroot ./calculator-sunbath
```
However, remember that ALICE isn't using this version in production.
