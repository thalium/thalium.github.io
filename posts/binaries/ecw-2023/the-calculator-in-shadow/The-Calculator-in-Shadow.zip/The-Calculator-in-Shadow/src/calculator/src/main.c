#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include "ast.tab.h"
#include "calc.h"
#include "debug.h"
#include "error.h"
#include "shadow.h"

typedef struct yy_buffer_state *YY_BUFFER_STATE;
extern YY_BUFFER_STATE yy_scan_string (const char *yy_str);
void yy_delete_buffer (YY_BUFFER_STATE b);

int main (int argc, char* argv[]) {
  blue_hour();

  int opt;
  bool opt_dump = false;
  while ((opt = getopt (argc, argv, "dh")) != -1) {
    switch (opt) {
      case 'd':
        opt_dump = true;
        break;
      case 'h':
        fprintf(stderr, "\n");
        fprintf(stderr, "Calculator.\n");
        fprintf(stderr, "ALICE's very own calculator :3\n");
        fprintf(stderr, "v1.0 for ECW 2023\n");
        #ifndef SUNBATH
        fprintf(stderr, "This build lurks in the Shadows...\n");
        #else
        fprintf(stderr, "This build lives in plainsight!\n");
        #endif
        fprintf(stderr, "\n");
      default:
        fprintf(stderr, "Usage: %s [-dh]\n", argv[0]);
        fprintf(stderr, "  -h  Display program info.\n");
        fprintf(stderr, "  -d  Dump calculation nodes (for debugging).\n");
        fprintf(stderr, "\n");
        exit(EXIT_FAILURE);
    }
  }

  setbuf(stdout, NULL);
  printf(">> ");
  char input[128] = "";
  if (scanf("%127[^\n]", input) == 0) {
    error(ERROR_BAD_INPUT);
  }
  printf("\n");

  node_t *node_root;
  YY_BUFFER_STATE buffer = yy_scan_string(input);
  yyparse(&node_root);
  yy_delete_buffer(buffer);

  if (opt_dump) {
    dump_nodes(node_root);
  }

  int64_t result;
  error(secure_calc(input, node_root, &result));
  printf("Result: %" PRIi64 "\n", result);

  exit(EXIT_SUCCESS);
}
