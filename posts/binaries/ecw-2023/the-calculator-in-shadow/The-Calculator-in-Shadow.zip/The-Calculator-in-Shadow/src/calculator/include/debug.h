#ifndef H_DEBUG
#define H_DEBUG

#define INDENT_INC 2

typedef struct node_t node_t;

void dump_nodes (node_t* node_root);

#endif /* H_DEBUG */
