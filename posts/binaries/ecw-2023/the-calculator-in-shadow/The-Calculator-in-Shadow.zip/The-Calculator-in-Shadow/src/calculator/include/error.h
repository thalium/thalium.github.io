#ifndef H_ERROR
#define H_ERROR

typedef enum error_kind {
    ERROR_NO_ERROR,
    ERROR_BAD_INPUT,
    ERROR_DUSK_MMAP,
    ERROR_LEXING_OVERFLOW,
    ERROR_LEXING_UNKNOWN,
    ERROR_NODE_KIND_UNKNOWN,
    ERROR_OPS_LIMIT,
    ERROR_PARSING,
    ERROR_POWER_NEGATIVE,
} error_kind;

void error (error_kind kind);

#endif /* H_ERROR */
