#include "debug.h"

#include <stdarg.h>
#include <stdio.h>

#include "calc.h"
#include "error.h"

void printf_indent(uint8_t indent, const char* format, ...) {
  printf("|");
  for (uint8_t i = 0; i < indent / 2; i++) {
    printf("  |");
  }
  printf(" ");

  va_list vlist;
  va_start(vlist, format);
  vprintf(format, vlist);
  va_end(vlist);
}

void dump_node (node_t* node, uint8_t indent) {
  printf_indent(indent, "kind = ");
  switch (node->kind) {
    case NODE_NUMBER:
      printf("NODE_NUMBER\n");
      break;
    case NODE_PLUS:
      printf("NODE_PLUS\n");
      break;
    case NODE_MINUS:
      printf("NODE_MINUS\n");
      break;
    case NODE_TIMES:
      printf("NODE_TIMES\n");
      break;
    case NODE_DIVIDE:
      printf("NODE_DIVIDE\n");
      break;
    case NODE_POWER:
      printf("NODE_POWER\n");
      break;
    default:
      error(ERROR_NODE_KIND_UNKNOWN);
      break;
  }

  if (node->kind == NODE_NUMBER) {
    printf_indent(indent, "value = %" PRIi64 "\n", node->content.value);
    return;
  }

  printf_indent(indent, "id = %" PRIu8 "\n", node->content.binop.id);
  printf_indent(indent, "\n");

  printf_indent(indent, "left:\n");
  printf_indent(indent, "\n");
  dump_node(node->content.binop.node_l, indent + INDENT_INC);
  printf_indent(indent, "\n");

  printf_indent(indent, "right:\n");
  printf_indent(indent, "\n");
  dump_node(node->content.binop.node_r, indent + INDENT_INC);
  printf_indent(indent, "\n");
}

void dump_nodes (node_t* node_root) {
  dump_node(node_root, 0);
  printf("\n");
}
