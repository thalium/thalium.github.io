#include "calc.h"

#include <stdbool.h>
#include <stdlib.h>

#include "error.h"
#include "shadow.h"

error_kind dispatch (node_t* node, int64_t results[], bool completed[]);

bool get_completion(node_t* node, bool completed[]) {
  IN_SHADOW

  return node->kind == NODE_NUMBER || completed[node->content.binop.id];
}

int64_t get_value(node_t* node, int64_t results[]) {
  IN_SHADOW

  if (node->kind == NODE_NUMBER) {
    return node->content.value;
  }

  return results[node->content.binop.id];
}

void do_plus (node_t* node, int64_t results[]) {
  IN_SHADOW

  node_t *node_l = node->content.binop.node_l;
  node_t *node_r = node->content.binop.node_r;
  results[node->content.binop.id] = get_value(node_l, results) + get_value(node_r, results);
}

void do_minus (node_t* node, int64_t results[]) {
  IN_SHADOW

  node_t *node_l = node->content.binop.node_l;
  node_t *node_r = node->content.binop.node_r;
  results[node->content.binop.id] = get_value(node_l, results) - get_value(node_r, results);
}

void do_times (node_t* node, int64_t results[]) {
  IN_SHADOW

  node_t *node_l = node->content.binop.node_l;
  node_t *node_r = node->content.binop.node_r;
  results[node->content.binop.id] = get_value(node_l, results) * get_value(node_r, results);
}

void do_divide (node_t* node, int64_t results[]) {
  IN_SHADOW

  node_t *node_l = node->content.binop.node_l;
  node_t *node_r = node->content.binop.node_r;
  results[node->content.binop.id] = get_value(node_l, results) / get_value(node_r, results);
}

void handle_power (node_t* node, int64_t results[], int64_t power) {
  IN_SHADOW

  if (power == 0) {
    return;
  }
  node_t *node_l = node->content.binop.node_l;
  results[node->content.binop.id] *= get_value(node_l, results);
  handle_power(node, results, --power);
}

error_kind do_power (node_t* node, int64_t results[]) {
  IN_SHADOW

  node_t *node_l = node->content.binop.node_l;
  node_t *node_r = node->content.binop.node_r;
  int64_t power = get_value(node_r, results);

  if (power < 0) {
    return ERROR_POWER_NEGATIVE;
  }
  if (power == 0) {
    results[node->content.binop.id] = 1;
    return ERROR_NO_ERROR;
  }

  results[node->content.binop.id] = get_value(node_l, results);
  handle_power(node, results, --power);

  return ERROR_NO_ERROR;
}

error_kind dispatch (node_t* node, int64_t results[], bool completed[]) {
  IN_SHADOW

  error_kind err;

  if (get_completion(node, completed)) {
    return ERROR_NO_ERROR;
  }

  node_t *node_l = node->content.binop.node_l;
  if (!get_completion(node_l, completed)) {
    err = dispatch(node_l, results, completed);
    if (err != ERROR_NO_ERROR) {
      return err;
    }
  }

  node_t *node_r = node->content.binop.node_r;
  if (!get_completion(node_r, completed)) {
    err = dispatch(node_r, results, completed);
    if (err != ERROR_NO_ERROR) {
      return err;
    }
  }

  switch (node->kind) {
    case NODE_PLUS:
      do_plus(node, results);
      break;
    case NODE_MINUS:
      do_minus(node, results);
      break;
    case NODE_TIMES:
      do_times(node, results);
      break;
    case NODE_DIVIDE:
      do_divide(node, results);
      break;
    case NODE_POWER:
      err = do_power(node, results);
      if (err != ERROR_NO_ERROR) {
        return err;
      }
      break;
    default:
      return ERROR_NODE_KIND_UNKNOWN;
      break;
  }

  completed[node->content.binop.id] = true;

  return ERROR_NO_ERROR;
}

void memzero (void *array, size_t length) {
  IN_SHADOW

  for (size_t i = 0; i < length; i++) {
    ((uint8_t*) array)[i] = 0;
  }
}

error_kind calc (node_t* node_root, int64_t* result) {
  IN_SHADOW

  int64_t results[MAX_OPS];
  bool completed[MAX_OPS];

  memzero(results, sizeof(int64_t) * MAX_OPS);
  memzero(completed, sizeof(bool) * MAX_OPS);

  if (node_root->kind == NODE_NUMBER) {
    *result = node_root->content.value;
    return ERROR_NO_ERROR;
  }

  error_kind err = dispatch(node_root, results, completed);
  if (err != ERROR_NO_ERROR) {
    return err;
  }

  *result = results[node_root->content.binop.id];
  return ERROR_NO_ERROR;
}

uint8_t count_ops (char input[]) {
  IN_SHADOW

  uint8_t count = 0;
  uint8_t i = 0;
  char c;

  do {
    c = input[i++];

    if (c == '+' || c == '-' || c == '/') {
      count++;
    } else if (c == '*') {
      count++;

      if (input[i] == '*') {
        i++;
      }
    }

  } while (c != '\0');

  return count;
}

error_kind secure_calc (char input[], node_t* node_root, int64_t* result) {
  IN_SHADOW

  if (MAX_OPS < count_ops(input)) {
    return ERROR_OPS_LIMIT;
  }

  return calc(node_root, result);
}
