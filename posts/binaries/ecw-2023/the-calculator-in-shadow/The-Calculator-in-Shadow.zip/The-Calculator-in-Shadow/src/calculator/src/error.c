#include "error.h"

#include <stdio.h>
#include <stdlib.h>

void error (error_kind kind)
{
  if (kind == ERROR_NO_ERROR) {
    return;
  }

  fprintf(stderr, "Calculator Error: ");
  switch (kind) {
    case ERROR_BAD_INPUT:
      fprintf(stderr, "Bad input.\n");
      break;
    case ERROR_DUSK_MMAP:
      fprintf(stderr, "Error while mmaping for dusk.\n");
      break;
    case ERROR_LEXING_OVERFLOW:
      fprintf(stderr, "Number overflow while lexing.\n");
      break;
    case ERROR_LEXING_UNKNOWN:
      fprintf(stderr, "Unknown token while lexing.\n");
      break;
    case ERROR_NODE_KIND_UNKNOWN:
      fprintf(stderr, "Unknown node kind.\n");
      break;
    case ERROR_OPS_LIMIT:
      fprintf(stderr, "More operations than the allowed limit.\n");
      break;
    case ERROR_PARSING:
      fprintf(stderr, "Parsing failed.\n");
      break;
    case ERROR_POWER_NEGATIVE:
      fprintf(stderr, "Negative power is not supported.\n");
      break;
    default:
      fprintf(stderr, "Unknown error.\n");
      break;
  }

  exit(EXIT_FAILURE);
}
